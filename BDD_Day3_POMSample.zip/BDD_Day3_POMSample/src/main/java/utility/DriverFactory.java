package utility;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DriverFactory {
    static WebDriver wd;

    public static WebDriver getDriver() {
        if (wd == null) {
            wd = new ChromeDriver();
        }
        return wd;
    }
}
/* Steps 
    WebDriver driver = DriverFactory.getDriver();*/
