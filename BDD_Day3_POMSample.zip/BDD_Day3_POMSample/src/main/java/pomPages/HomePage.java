package pomPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
	
	//Step-1
	//Declare the WebDriver instance
	//Step-2
	//Create the page constructor to initialize webdriver
	
	//Step-3
	//locators
	//Step-4
	//Test methods
	
	WebDriver wd;
	//Locator 
	By text1=By.xpath("//*[@id=\"top\"]/div/h3");
	
	By btn1 = By.xpath("//*[@id='btn-make-appointment']");
	
	//String exp_home = "We Care About Your Health";
	
	//page class constructor
	public HomePage(WebDriver wd) {
		this.wd=wd;
		
	}
	
	// Automation step
	
	public void LaunchApp() {
		wd.get("https://katalon-demo-cura.herokuapp.com/");
	}
	
	//validation
	
	public String validate_home() {
	 String str=wd.findElement(text1).getText();
	 return str;
		
	}
	
	public void ClickMA() {
		wd.findElement(btn1).click();
	}
	
	

}
