package pomPages;

public class MyAccount {

}
