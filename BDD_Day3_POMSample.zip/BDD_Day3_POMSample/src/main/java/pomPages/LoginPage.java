package pomPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
	// WebDriver instance
	WebDriver wd;
	
	
	By unm = By.xpath("//*[@id='txt-username']");
	By pwd = By.xpath("//*[@id='txt-password']");
	By lgin = By.xpath("//*[@id='btn-login']");
		
	// Constructor
	public LoginPage(WebDriver wd) {
		this.wd = wd;
		
	}
	
	// steps
	
	public void Enter_Unm() {
		wd.findElement(unm).sendKeys("John Doe");
		
	}
	
	public void Enter_Passcode(String pass1) {
		wd.findElement(pwd).sendKeys(pass1);
	}
	
	
	
	public void Click_Login() {
		wd.findElement(lgin).click();
	}
	
	

}
