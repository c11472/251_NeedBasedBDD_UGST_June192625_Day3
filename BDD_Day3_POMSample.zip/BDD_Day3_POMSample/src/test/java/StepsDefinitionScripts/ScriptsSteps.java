package StepsDefinitionScripts;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;
import pomPages.HomePage;
import utility.DriverFactory;

public class ScriptsSteps {
	// Accessing static driver
	WebDriver wd = DriverFactory.getDriver(); // classname.method();
	// Page objects
	HomePage hm = new HomePage(wd);
    pomPages.LoginPage lginp = new pomPages.LoginPage(wd);

	
	String exp_home = "We Care About Your Health";
	@Given("I enter the url in chrome")
	public void i_enter_the_url_in_chrome() {
		 wd.get("https://katalon-demo-cura.herokuapp.com/");
		
	}

	 
	
	 @When("I can validate the homepage")
	 public void I_can_validate_the_homepage() throws InterruptedException {
		String actData= hm.validate_home();
		// check point -- Passed
		Assert.assertEquals(exp_home, actData);
		Thread.sleep(5000);
		 hm.ClickMA();
		
		
		
	
		 
	 }
	 // second
	   @Given("I am in login page")
	   public void LoginPage() {
		   
		   System.out.println("I am in Loginpage");
		   
	   }
	   
	   @When("I enter username")
	   public void i_enter_username() {
	       // Write code here that turns the phrase above into concrete actions
		   lginp.Enter_Unm();
	   }
	   
	   @When("I enter password")
	   public void  I_enter_password() {
		   lginp.Enter_Passcode("ThisIsNotAPassword");
	   
	   }
	   // after login we need to assert
	   
	   

} 

	 
	 