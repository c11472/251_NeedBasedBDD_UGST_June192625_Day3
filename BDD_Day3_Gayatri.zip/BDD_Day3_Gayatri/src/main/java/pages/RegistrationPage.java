package pages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class RegistrationPage {
    WebDriver driver;

    public RegistrationPage(WebDriver driver) {
        this.driver = driver;
    }

    By regsLink = By.xpath("//*[@id='column-right']/div/a[2]");
   
    public void register() {
    	driver.findElement(regsLink).click();
    	
            }
}
