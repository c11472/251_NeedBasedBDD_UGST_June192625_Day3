package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ForgotPassPage {
	WebDriver driver;
	
	By fp = By.xpath("//*[@id='column-right']/div/a[3]");
	By dat = By.xpath("//*[@id='input-email']");
	
	 public ForgotPassPage(WebDriver driver) {
		this.driver=driver;
		
	}
	
	public void click_forgot() throws InterruptedException {
		Thread.sleep(4000);
		driver.findElement(fp).click();		
	}
	
	public void EnterData( String data) {
		driver.findElement(dat).sendKeys("testdata@email.com");
	}
	
	

}
