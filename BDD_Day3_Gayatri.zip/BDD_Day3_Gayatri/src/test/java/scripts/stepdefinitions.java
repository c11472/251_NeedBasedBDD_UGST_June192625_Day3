package scripts;


import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;

import pages.ForgotPassPage;
import pages.LoginPage;
import pages.RegistrationPage;
import utils.DriverFactory;

public class stepdefinitions {
    WebDriver driver = DriverFactory.getDriver();
    LoginPage loginPage = new LoginPage(driver); // Page class object
    RegistrationPage regPage = new RegistrationPage(driver);
    ForgotPassPage fps1 = new ForgotPassPage(driver);

    @Given("I am on the login page")
    public void i_am_on_login_page() {
        driver.get("https://awesomeqa.com/ui/index.php?route=account/login");
    }

    @When("I enter valid username and password")
    public void enter_valid_login() {
        loginPage.enterUsername("usertest");//method call
        loginPage.enterPassword("passtest"); // method call
    }

    @And("I click the login button")
    public void click_login() {
        loginPage.clickLogin();
    }
    @Then("I should be redirected to the homepage")
    public void verify_homepage() {
    	System.out.println("pass test");
    }

    @Given("I am on the registration page")
    public void i_am_on_register_page() {
        regPage.register();
    }
    
    
    //****************
    
    @Given("I want to get into forgot password page")
    public void I_want_to_get_into_forgot_password_page() throws InterruptedException {
    	
    	fps1.click_forgot();
    }
    
    @When("I am checking the title")
    public void I_am_checking_the_title() {
    	fps1.EnterData("gayatri");
    }
   

    }
